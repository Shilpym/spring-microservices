insert into exchange_value(id,currency_from,currency_to,conversion_multiple,port) values(100001,'USD','INR',65,0)
insert into exchange_value(id,currency_from,currency_to,conversion_multiple,port) values(100002,'AUD','INR',35,0)
insert into exchange_value(id,currency_from,currency_to,conversion_multiple,port) values(100003,'EUR','INR',75,0)